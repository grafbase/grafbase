import { writeFileSync } from 'fs'

const configFile = process.argv.slice(2)[0]
const resultFile = process.argv.slice(2)[1]

const config = require(configFile)

if (config.default == null) {
  console.error('Default configuration not defined in grafbase.config.ts. Did you remember to export it?')
  process.exit(1)
}

writeFileSync(resultFile, config.default.toString(), {
  flag: 'w',
})
